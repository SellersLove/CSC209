#!/bin/bash

INFILE=$1
BINDIR="./bin"
OUTFILE="${BINDIR}/${INFILE%.c}"

# Throw away the shell scripts' argv[0]
shift

# If the BINDIR does not exist, create it now
[[ ! -d "${BINDIR}/" ]] && mkdir "${BINDIR}/"


gcc -Wall "${INFILE}" -o wc209