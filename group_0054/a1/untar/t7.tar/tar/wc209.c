#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <getopt.h>


int countlines(char *filename);
int countwords(char *filename);
int countchars(char *filename);
int isspace(int c);
int main(int argc, char *argv[]){
    int opt;
    int i;  
    int check = 0;
    int lflag = 0;
    int wflag = 0;
    int cflag = 0;
    
    while ((opt = getopt(argc, argv, "lwc")) != -1) {
      switch (opt) {
               case 'l':
                  lflag = 1;
                  check = 1;
                  break;
               case 'w':
                  wflag = 1;
                  check = 1;
                  break;
               case 'c':
                  cflag = 1;
                  check = 1;
                  break;
               default:
                    check = 2;
                    printf("Error\n");
               }
        }
        if(check == 2){
          lflag = 0;
          wflag = 0;
          cflag = 0;
        }
        else if(!lflag && !wflag && !cflag && !check){
          lflag = 1;
          wflag = 1;
          cflag = 1;
        }
        
        // read the file 
        
        for(i = optind; i < argc; i++){
            if(lflag){
              printf("   %d   ",countlines(argv[i])); 
            } 
            if(wflag){
              printf("   %d   ",countwords(argv[i])); 
            }
            if(cflag){
              printf("   %d   ",countchars(argv[i]) ); 
            }
            printf("\n"); 
        }
      

        return 0;
    }

int countlines(char *filename){
  
  FILE *fp = fopen(filename,"r");
  int ch=0;
  int lines=0;

  if (fp == NULL){
       return 0;
  }
 
   while(!feof(fp))
  {
    ch = fgetc(fp);
    if(ch == '\n')
    {
      lines++;
    }
  }
  fclose(fp);
  return lines;
}

int countwords(char *filename)
{
   FILE *fp = fopen(filename,"r");
   int word=0;
   int update_counter = 0;
    for ( ;; )
    {
       int ch = fgetc(fp);
       if (ch == EOF )
       {
          
          if(update_counter){
            word++;
            break;
          }
          else{
            break;
          }
       }
       if (!isspace(ch))
       {
          update_counter = 1;
 
       }
       if (isspace(ch) && update_counter )
       {
          word++;
          update_counter = 0;
       }
    }
   fclose(fp);
   return word;
}

int countchars(char *filename){

   FILE *fp = fopen(filename,"r");
   char ch;
   int chars=0;

   if (fp == NULL){
       return 0;
    }
   while((ch=getc(fp))!=EOF)
   {
        chars++;
   }
   fclose(fp);
   return chars;
}
